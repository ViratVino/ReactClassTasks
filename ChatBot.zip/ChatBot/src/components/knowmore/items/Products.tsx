const Products = () => {
  return (
    <div>
      <p><a href="https://www.fireflink.com/fireflink-platform" target="blank">FireFlink Platform</a></p>
      <p><a href="https://www.fireflink.com/fireflink-finder" target="blank">FireFlink Finder</a></p>
      <p><a href="https://www.fireflink.com/fireflink-cloud" target="blank">FireFlink Cloud</a></p>
    </div>
  )
}

export default Products