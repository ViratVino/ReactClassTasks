const Resourses = () => {
  return (
    <div>
      <h3>Resourses</h3>
      <p><a href="https://www.fireflink.com/documentation" target="_blank">Documentation</a></p>
      <p><a href="https://www.fireflink.com/video-tutorial"  target="_blank">Video Tutorials</a></p>
      <p><a href="https://www.fireflink.com/release-notes/latest-version"  target="_blank">Release Notes</a></p>
      
    </div>
  )
}

export default Resourses