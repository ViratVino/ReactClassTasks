const ContactUs = () => {
  return (
    <div>
      <h3>Details</h3>
      <p>Phone No: +91 99000 10384</p>
      <p>Email ID:contactus@fireflink.com</p>
      <p>Address :4th floor, IndiQube South Mile building, Vijayarangam Layout, Jayanagar, Bengaluru, Karnataka, 560070, India.</p>
      <p><a href="https://www.fireflink.com/contactus" target="blank">view more...</a></p>
    </div>
  )
}

export default ContactUs