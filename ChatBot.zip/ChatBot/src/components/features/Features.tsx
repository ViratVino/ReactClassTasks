const Features = () => {
  return (
    <div>
        <h3>Types Of Automation</h3>
        <p>1.Web</p>
        <p>2.Web Service</p>
        <p>3.Mobile</p>

    </div>
  )
}

export default Features