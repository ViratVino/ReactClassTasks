import ChatBot from "./components/ChatBot"


function App() {

  return (
    <>
      <div>
          <ChatBot></ChatBot>
      </div>
     
    </>
  )
}

export default App
