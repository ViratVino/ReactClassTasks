
import MyComponent from './Chat';
const App = () => {
return (
    <div>
      <MyComponent/>
    </div>
  )
}

export default App