import React from 'react';
import"./Chat.sass"
import { HiPaperAirplane } from "react-icons/hi2";


const MyComponent: React.FC = () => {
  return (
    <main>
      <section id="container">
        <header id="head">
          <div id="img"></div>
          <div id="h5">
            <h5>Active...</h5>
          </div>
        </header>
        <footer id="footer">
          <div id="text">
            <input type="text" placeholder="enter text....." />
            <div id="icon"><HiPaperAirplane /></div>
          </div>
        </footer>
      </section>
    </main>
  );
}

export default MyComponent;
